var vheight = window.screen.height-200
var vwidth =  window.screen.width-200
function winopen(file){	
window.open(file,"","height="+vheight+",width="+vwidth+",top =0,left=0,toolbar=no,location=no,scrollbars=yes,status=no,menubar=no,resizable=yes");
}