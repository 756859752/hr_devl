package web.controller.ybc;

public class UserLogin {
	String user_true_name=null;

	public String getUser_true_name() {
		return user_true_name;
	}

	public void setUser_true_name(String user_true_name) {
		this.user_true_name = user_true_name;
	}
	
}
